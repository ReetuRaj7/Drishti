import cv2
import torch
from models.experimental import attempt_load
from utils.general import non_max_suppression
from utils.torch_utils import select_device
import pandas
import time
import pyttsx3

def scale_coords(img_shape, coords, img0_shape, ratio_pad=None):
    # Rescale coordinates from img_size to img0 size
    if ratio_pad is None:  # calculate from img_shape and img0_shape
        gain = max(img_shape) / max(img0_shape)  # gain  = old / new
        pad = (img_shape[1] - img_shape[0]) / 2  # width padding
        coords[:, [0, 2]] -= pad
        coords[:, :4] /= gain
        clip_coords(coords, img0_shape)
    else:  # ratio_pad given
        gain_pad = gain_pad_transform(img_shape, img0_shape, ratio_pad)
        coords[:, :4] = affine_transform(coords[:, :4], gain_pad)
    return coords


labels = {0:'Apple',1:'Banana',2:'Pine Apple'}

def format_labels(labels):
    label_list = sorted(list(labels))
    if len(label_list) == 0:
        return 'Nothing'
    if len(label_list) == 1:
        return label_list[0]
    else:
        return ', '.join(label_list[:-1]) + ' and ' + label_list[-1]


def load_main():
	device = select_device('')
	model = attempt_load('best.pt')
	model.to(device).eval()

	# Initialize camera or video stream
	cap = cv2.VideoCapture(0) # or cv2.VideoCapture('video_file.mp4')

	# Initialize the text-to-speech engine
	engine = pyttsx3.init()
	engine.setProperty('rate',150)

	# Initialize variables for tracking time and labels
	start_time = time.time()
	label_names = set()

	while True:
	    # Capture frame from camera or video stream
	    ret, frame = cap.read()
	    if not ret:
	        break

	    # Resize the frame to match the expected input shape of the model
	    frame = cv2.resize(frame, (640, 480))
	    # Convert the frame to RGB color format with 3 color channels
	    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

	    # Run object detection on the frame
	    img = torch.from_numpy(frame).float().to(device)

	    # Normalize the pixel values to be between 0 and 1
	    img /= 255.0

	    # If the image has only one channel, add a batch dimension
	    if img.ndim == 2: # Grayscale image
	        img = img.unsqueeze(0).unsqueeze(0)
	    elif img.ndim == 3 and img.shape[0] == 3: # RGB image with channels first
	        img = img.unsqueeze(0)
	    elif img.ndim == 3 and img.shape[2] == 3: # RGB image with channels last
	        img = img.permute(2, 0, 1).unsqueeze(0)
	    else: # Unsupported image format
	        print('Unsupported image format')
	        continue

	    # Run object detection on the image
	    with torch.no_grad():
	        detections,_ = model(img)

	    # Draw the detections on the frame
	    results = detections.cpu().numpy()
	    results = non_max_suppression(torch.from_numpy(results), conf_thres=0.5, iou_thres=0.5)
	    results = pandas.DataFrame(results[0], columns=["xmin", "ymin", "xmax", "ymax", "confidence", "class"])
	    
	    for i, row in results.iterrows():
	        x1, y1, x2, y2 = int(row['xmin']), int(row['ymin']), int(row['xmax']), int(row['ymax'])
	        label = row['class']
	        confidence = row['confidence']
	        
	        
	        # Draw a rectangle around the object
	        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
	        
	        label = labels[int(label)]
	        # Draw the label and confidence score
	        label_text = f"{label}: {confidence:.2f}"
	        cv2.putText(frame, label_text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

	        # Add the label name to the set of detected labels
	        label_names.add(label)
	        
	        

	    # Display the frame with the detected objects
	    cv2.imshow('frame', frame)
	    
	    # Check if 10 seconds have elapsed since the last announcement
	    elapsed_time = time.time() - start_time
	    
	    if elapsed_time > 10:
	        # Reset the timer
	        start_time = time.time()
	        # Get the names of the labels that were detected
	        
	        label_names = set(results['class'])
	        label_names = set([int(label) for label in label_names])
	        label_names = set([labels[label] for label in label_names])

	        # Convert the set of label names to a comma-separated string
	        label_names_str = format_labels(label_names)

	        # Speak the names of the detected labels
	        if label_names_str != 'Nothing':
	        	engine.say(f"I see {label_names_str}, which can weigh around {len(label_names) * 250} grams")
	        else:
	            engine.say(f"I can see {label_names_str}, please focus camera properly")
	        engine.runAndWait()

	    # Check if the 'q' key was pressed to quit the program
	    if cv2.waitKey(10) == ord('q'):
	        break

	# Release the camera or video stream and close the window
	cap.release()
	cv2.destroyAllWindows()


if __name__ == "__main__":
	load_main()